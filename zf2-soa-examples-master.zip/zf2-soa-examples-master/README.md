# ZF2 SOA Examples

These are primarily examples for a presentation given on [ZF2 SOA](http://www.mikewillbanks.pw/slides/zf2-soa.html).

ExampleEntity.php is able to run to show how you can leverage events.  The rest
of the examples are such that you might design out a module but it is not a
working module.

Use php composer.phar install to get dependencies for ExampleEntity.php.
