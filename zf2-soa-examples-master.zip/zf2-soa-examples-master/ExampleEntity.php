<?php

require 'vendor/autoload.php';

use Zend\EventManager\Event;
use Zend\EventManager\EventManager;
use Zend\EventManager\EventManagerAwareTrait;
use Zend\EventManager\EventManagerAwareInterface;
use Zend\InputFilter\Factory as InputFilterFactory;

class ExampleEntity implements EventManagerAwareInterface {

    use EventManagerAwareTrait;

    protected $inputFilter;
    protected $name;

    public function __construct()
    {
        $em = $this->getEventManager();
        $em->attach('property.set', array($this, 'filter'));
        $em->attach('property.set', array($this, 'onPropertySet'));
        $em->attach('property.get', array($this, 'onPropertyGet'));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter)
        {
            $factory = new InputFilterFactory();
            $this->inputFilter = $factory->createInputFilter(array(
                'name' => array(
                    'name' => 'name',
                    'filters' => array(
                        array('name' => 'StringTrim'),
                        array('name' => 'StringToLower'),
                    ),
                ),
            ));
        }

        return $this->inputFilter;
    }

    public function getName()
    {
        return $this->get('name');
    }

    public function setName($value)
    {
        return $this->set('name', $value);
    }

    public function set($name, $value)
    {
        $argv = compact('name', 'value');
        $argv = $this->getEventManager()->prepareArgs($argv);
        $result = $this->getEventManager()->trigger(
            'property.set',
            $this,
            $argv
        );

        return $this;
    }

    public function get($name)
    {
        $result = $this->getEventManager()->trigger(
            'property.get',
            $this,
            array('name' => $name)
        );

        return $result->last();
    }

    public function filter(Event $e)
    {
        $params = $e->getParams();
        $input = $this->getInputFilter()->get($params['name']);
        $params['value'] = $input->getFilterChain()->filter($params['value']);

        return $params['value'];
    }

    public function onPropertySet(Event $e)
    {
        $params = $e->getParams();

        $this->{$params['name']} = $params['value'];

        return $params['value'];
    }

    public function onPropertyGet(Event $e)
    {
        $name = $e->getParam('name');

        return $this->$name;
    }
}

$test = new ExampleEntity();
$test->setName('Foo ');
var_dump($test->getName());
