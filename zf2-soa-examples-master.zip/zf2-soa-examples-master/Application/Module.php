<?php

class Module
{
    public function getControllerConfig()
    {
        return array(
            'factories' => array(
                'product-controller' => function ($sm) {
                    $controller = new Controller\ProductController();
                    $controller->setProductService(
                        $sm->get('Application\Service\Product')
                    );
                },
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'Application\Service\Product' => function ($sm) {
                    $productService = new Service\Product();
                    $productService->setMapper(
                        $sm->get('Application\Mapper\Product')
                    );

                    $productService->getEventManager()->attach('create.post', function ($e) use ($sm) {
                        $product = $e->getParam('entity');

                        $priceService = $sm->get('Application\Service\Price');
                        $priceService->createPrice($product);
                    });

                    return $productService;
                },
                'Application\Mapper\Product' => function ($sm) {
                    $productMapper = new Mapper\Product();
                    $productMapper->setDataSource(
                        $sm->get('Application\DataSource\Product')
                    );
                    return $productMapper;
                },
                'Application\DataSource\Product' => function ($sm) {
                    $dataSource = new DataSource\Product();
                    $dataSource->setTableGateway(
                        new Zend\Db\TableGateway\TableGateway('product', $sm->get('db'))
                    );
                    return $dataSource;
                }
            ),
        );
    }
}
