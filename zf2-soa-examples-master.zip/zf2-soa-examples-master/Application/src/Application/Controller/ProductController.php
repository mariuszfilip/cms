<?php

namespace Application\Controller;

use Application\Service;
use Application\Entity;
use Zend\Mvc\Controller\AbstractActionController;

class ProductController extends AbstractActionController
{
    protected $service;

    public function setProductService(Service\Product $service)
    {
        $this->service = $service;
    }

    public function listAction()
    {
        return array(
            'list' => $this->service->getList(),
        );
    }

    public function createAction()
    {
        $request = $this->getRequest();
        $form = new Form\Product();

        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $entity = new Entity\Product($form->getData());
                if ($this->service->create($entity)) {
                    $this->flashMessenger()->addMessage('Product created');
                    return $this->redirect('/');
                }
            }
        }

        return array(
            'form' => $form,
        );
    }
}
