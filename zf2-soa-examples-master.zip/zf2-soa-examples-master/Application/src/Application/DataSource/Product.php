<?php

namespace Application\DataSource;

use Zend\Db\TableGateway\TableGateway;

class Product
{
    protected $gateway;

    public function setTableGateway(TableGateway $gateway)
    {
        $this->gateway = $gateway;
    }

    public function findAll()
    {
        return $this->gateway->select();
    }
}
