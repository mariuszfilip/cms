<?php

namespace Application\Mapper;

use Application\DataSource;
use Application\Entity;

class Product
{
    protected $dataSource;

    public function setDataSource(DataSource\Product $dataSource)
    {
        $this->dataSource = $dataSource;
    }

    public function findAll()
    {
        return new Cursor(
            $this->dataSource->findAll(),
            new Entity\Product()
        );
    }
}
