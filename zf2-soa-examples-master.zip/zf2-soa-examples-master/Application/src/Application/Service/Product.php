<?php

namespace Application\Service;

use Application\Mapper;

class Product
{
    protected $mapper;

    public function setMapper(Mapper\Product $mapper)
    {
        $this->mapper = $mapper;
    }

    public function getList()
    {
        return $this->mapper->getList();
    }
}
